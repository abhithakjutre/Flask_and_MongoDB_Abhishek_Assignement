# Flask & MongoDB – TuteDude Assignment

## Run
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# edit .env with your MongoDB Atlas URI
python3 app.py
```
Open http://127.0.0.1:5000/

## Routes
- `/api` reads `data.json` and returns JSON.
- `/` displays the form.
- `/submit` inserts form data into MongoDB Atlas.
- `/success` displays the required success message.

Never commit `.env` or your MongoDB password.
