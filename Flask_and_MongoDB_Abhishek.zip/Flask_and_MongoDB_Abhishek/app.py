import json
import os
from pathlib import Path
from flask import Flask, jsonify, render_template, request, redirect, url_for
from dotenv import load_dotenv
from pymongo import MongoClient
from pymongo.errors import PyMongoError
load_dotenv()
app=Flask(__name__)
BASE_DIR=Path(__file__).resolve().parent
DATA_FILE=BASE_DIR/'data.json'
MONGO_URI=os.getenv('MONGO_URI')
MONGO_DB=os.getenv('MONGO_DB','tutedude_assignment')
MONGO_COLLECTION=os.getenv('MONGO_COLLECTION','submissions')
collection=None

print("Base Dir", BASE_DIR)
print("Mongo url ", MONGO_URI)
print("Mongo DB", MONGO_DB)
print("Mongo Collection", MONGO_COLLECTION) 
if MONGO_URI:
    try:
        client=MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
        client.admin.command('ping')
        collection=client[MONGO_DB][MONGO_COLLECTION]
    except PyMongoError as e:
      print("MongoDB connection failed:", repr(e))
      client = None
      collection = None
@app.route('/')
def home(): return render_template('index.html')
@app.route('/api')
def api():
    try:
        with open(DATA_FILE,encoding='utf-8') as f: data=json.load(f)
        return jsonify(data)
    except (FileNotFoundError,json.JSONDecodeError) as e: return jsonify({'error':str(e)}),500
@app.route('/success')
def success(): return render_template('success.html')
@app.route('/submit',methods=['POST'])
def submit():
    name=request.form.get('name','').strip(); email=request.form.get('email','').strip(); message=request.form.get('message','').strip()
    form={'name':name,'email':email,'message':message}
    if not name or not email or not message: return render_template('index.html',error='All fields are required.',form=form),400
    if collection is None: return render_template('index.html',error='MongoDB Atlas is not connected. Check MONGO_URI and Atlas network access.',form=form),500
    try:
        collection.insert_one({'name':name,'email':email,'message':message})
        return redirect(url_for('success'))
    except PyMongoError as e: return render_template('index.html',error=f'Database error: {e}',form=form),500
if __name__=='__main__': app.run(debug=True)
